# prgrms-pandas-beginner-training
파이썬 입문 강의 실습 작성용
